
# Nerd Fonts

This is font-patcher python script (and required source files) from a Nerd Fonts release.

## Running

* To execute run: `fontforge --script ./font-patcher --complete <YOUR FONT FILE>`
* For more CLI options and help: `fontforge --script ./font-patcher --help`

## Further info

For more information see:
* https://github.com/ryanoasis/nerd-fonts/
* https://github.com/ryanoasis/nerd-fonts/releases/latest/

## Version
This archive is created from

        commit 4b528bf1b5ea638965bc9f634bd7a13301060548
        Author: Finii <Finii@users.noreply.github.com>
        Date:   Fri Apr 26 11:11:43 2024 +0000
        
            [ci] Update FontPatcher.zip
